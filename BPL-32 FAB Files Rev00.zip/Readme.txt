BOARD INFO:
PART NUMBER: BPL-32 Rev00
DIMENSIONS (mm): 80 x 100
LAYERS: 2 (RIGID)
MATERIAL: FR4 TG 130-140
THICKNESS: 1.6mm +/- 10%
MINIMUM TRACK: 0.254 mm
MINIMUM GAP: 0.254 mm
MINIMUM THROUGH HOLE VIA:  0.711 mm (DRILL)
OUTER COPPER (OZ): 1
MASK SIDES: BOTH
MASK COLOR: BLUE
SILKSCREEN SIDES: BOTH
SILKSCREEN COLOR: WHITE
FINAL FINISH TYPE: HASL
VIAS FINISH: NONE
ELECTRICAL TEST - 100% IPCD356
IMPEDANCE CONTROL: NO
FABRICATION SPECIFICATION*: IPC-A-600 CLASS 1


Gerber Files:
*.GTL - TOP LAYER
*.GTO - Top Overlay
*.GTP - Top Paste
*.GTS - Top Solder
*.GPT - Top Pad Master
*.GBL - BOTTOM LAYER
*.GBS - Bottom Solder
*.GBP - Bottom Paste
*.GBO - Bottom Overlay
*.GD1 - Drill Drawing Layer
*.GKO - Keepout Layer
*.GM1 - Board Outline
*.GM4 - Board Dimensions
*.GM7 - Manufacturing Notes
*.GM12 - Scoring/Routing
*.GM16 - Page Frame
*.GPT - Top Pad Master
*.GPB - Bottom Pad Master


